from sqlalchemy.orm import declarative_base

Base = declarative_base()


# ORM: object relational mapping base class
# OOP : object oriented programming

# ERD --> class relational
# Lập trinhf hướng đối tượng (logic) mapping class -> table (database)